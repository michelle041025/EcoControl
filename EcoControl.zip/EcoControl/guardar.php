<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include("conexion.php");

$nombre = $_POST['nombre'];
$tipo = $_POST['tipo'];
$descripcion = $_POST['descripcion'];

$sql = "INSERT INTO reportes (nombre, tipo, descripcion)
VALUES ('$nombre', '$tipo', '$descripcion')";

if ($conexion->query($sql) === TRUE) {
    echo "Reporte guardado correctamente 🚀";
} else {
    echo "Error: " . $conexion->error;
}
?>