<?php
$conexion = new mysqli("localhost", "root", "", "ecocontrol");

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}
?>