<?php
include("conexion.php");

$sql = "SELECT * FROM reportes";
$resultado = $conexion->query($sql);
?>

<h2>Reportes registrados</h2>

<table border="1">
<tr>
    <th>Nombre</th>
    <th>Tipo</th>
    <th>Descripción</th>
    <th>Fecha</th>
</tr>

<?php
while($fila = $resultado->fetch_assoc()){
    echo "<tr>
        <td>".$fila['nombre']."</td>
        <td>".$fila['tipo_contaminacion']."</td>
        <td>".$fila['descripcion']."</td>
        <td>".$fila['fecha']."</td>
    </tr>";
}
?>
</table>